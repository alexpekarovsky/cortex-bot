# Cortex XSIAM Custom Tools v2.0.0

Add 84 custom tools to the official Palo Alto Networks Cortex MCP Server.

## What This Package Provides

**84 custom tools** organized into:
- Case Management (3 tools)
- Issue Management (2 tools)
- Response Actions (11 tools)
- Threat Hunting (7 tools)
- Script Execution (6 tools)
- XSOAR SDK (10 tools)
- Development Guides (9 tools)
- Content Generators (11 tools)
- Widget Management (3 tools)
- Playbook Management (3 tools)
- Integration Discovery (2 tools)
- Testing (1 tool)
- Utilities (16 tools)

**Total: 6 base tools + 84 custom tools = 90 tools**

## Prerequisites

1. Official Cortex MCP Server installed (Dec 2025 or later)
2. Python 3.12+
3. fastmcp 2.13.1+
4. Active Cortex XSIAM tenant with API key

## Installation

### Step 1: Locate Your MCP Server

```bash
cd /path/to/cortex-mcp
```

### Step 2: Extract Custom Tools

```bash
# Extract the package
tar -xzf cortex-custom-tools-v2.0.0.tar.gz
# or
unzip cortex-custom-tools-v2.0.0.zip

# Copy to your MCP server
cp -r cortex-custom-tools-v2.0.0/custom_components/* src/usecase/custom_components/
```

### Step 3: Install Additional Dependencies

```bash
source venv/bin/activate  # Activate your MCP venv
pip install -r cortex-custom-tools-v2.0.0/requirements.txt
```

### Step 4: Restart MCP Server

```bash
pkill -f "main.py"
python src/main.py
```

### Step 5: Verify

```bash
# In Claude Code or Claude Desktop
/mcp
# Should show 90 tools (was 6)
```

## Dependencies

- fastmcp >= 2.13.1
- aiohttp >= 3.13.3
- pydantic >= 2.0.0
- requests >= 2.31.0

## Support

For issues or questions: https://github.com/PaloAltoNetworks/cortex-mcp/issues
