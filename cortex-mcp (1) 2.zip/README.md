# cortex-mcp

A Python based integration for Cortex MCP (Model Context Protocol).

## Getting Started

### Prerequisites

- Python 3.13 or higher / container environment
- Cortex API credentials (Standard API key and API key ID)

### Installation

#### Option 1: Using Docker

Create a `.env` file with the following environment variables:
```
CORTEX_MCP_PAPI_URL=https://<your-tenant-url>,
CORTEX_MCP_PAPI_AUTH_HEADER=<your_api_key>, 
CORTEX_MCP_PAPI_AUTH_ID=<your_api_key_id>,
(optional - defaults to stdio)MCP_TRANSPORT=stdio/streamable-http
(optional, for streamable-http)MCP_HOST=0.0.0.0
(optional, for streamable-http)MCP_PORT=8080
(optional, for streamable-http)MCP_PATH=/api/v1/stream/mcp
```

Build the Docker container:

```bash
docker build -t cortex-mcp .
```

#### Option 2: Locally Using Poetry (Virtual Environment)

1. Install Poetry if you haven't already:
```bash
curl -sSL https://install.python-poetry.org | python3 -
```

2. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate
```

3. Install project dependencies:
```bash
poetry install
```

### Running The MCP Server

#### CLI
- See the [CLI](src/README.md) readme

#### Claude Desktop

-  Open the Claude configuration file (accessible from the `Developer` pane in Claude Desktop settings) and add the following MCP server configuration:


Docker Container:
```json
{
  "mcpServers": {
    "Cortex MCP Server": {
      "command": "docker",
      "args": [
        "run",
        "--env-file",
        "/path/to/.env",
        "-i",
        "--rm",
        "cortex-mcp"
      ]
    }
  }
}
```


Local (the mcp server would have to be [installed locally beforehand](#option-2-locally-using-poetry-virtual-environment)):
```json
{
  "mcpServers": {
    "Cortex MCP Server": {
      "command": "<path to cortex-mcp virtual environment>/bin/python",
      "args": [
        "<path to cortex-mcp>/src/main.py"
      ],
       "env": {
          "CORTEX_MCP_PAPI_URL": "https://<your-tenant-url>",
          "CORTEX_MCP_PAPI_AUTH_HEADER": "<your_api_key>", 
          "CORTEX_MCP_PAPI_AUTH_ID": "<your_api_key_id>",
          "MCP_TRANSPORT": "<stdio/streamable-http>"
   }
    }
  }
}
```


## Development

### Project Structure
```
src/
├── cli.py                           # Command line interface
├── main.py                          # Main application entry point
├── config/                          # Configuration modules
├── entities/                        # Data models and entity classes
├── pkg/                             # Internal package utilities and helpers
├── service/                         # Service layer implementations
└── usecase/                         # Business logic and use cases
    ├── builtin_components/          # MCP components that come with the package
    │   ├── openapi/
    │   └── python modules
    ├── custom_components/           # MCP components that are user-defined 
    │   ├── openapi/
    │   └── python modules
    └── remote_components/           # MCP components that are distributed and updated by Cortex** 
        ├── openapi/
        └── python modules

tests/
├── e2e/                             # End-to-end tests
└── individual test files
```
** When the user runs the [CLI](src/README.md) update command, any new or updated components provided by Cortex are automatically downloaded into the remote_components folder.  
During each update, the folder is fully replaced and all existing contents are recreated.

Do not add custom tools to this directory, as it is managed entirely by Cortex and will be overwritten on every update.

### Adding custom MCP components

To add custom MCP components, follow this [guide](src/usecase/README.md).

### Coding

Run tests:
```bash
poetry run pytest
```

Format code:
```bash
poetry run black .
poetry run isort .
```

Debug:
The best way to debug MCP servers is with the [MCP inspector](https://github.com/modelcontextprotocol/inspector).
Aside from that, end-to-end tests can be run and added under `tests/e2e`.

